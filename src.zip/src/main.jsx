import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowDown, ArrowUpRight, BrainCircuit, CheckCircle2, ChevronRight,
  Code2, Cpu, ExternalLink, Github, GraduationCap, Layers3, Linkedin,
  Mail, Menu, Network, ShieldCheck, Sparkles, Terminal, X
} from "lucide-react";
import "./styles.css";

const profile = {
  name: "Seif Elmahalawy",
  email: "seif.hossameldein@gmail.com",
  linkedin: "https://linkedin.com/in/seifelmahalawy",
  github: "https://github.com/seifelmahalawy",
};

const projects = [
  {
    title: "ID Reader — Egyptian ID Verification",
    period: "Sep 2025 — Jul 2026",
    featured: true,
    icon: ShieldCheck,
    description:
      "An AI-powered identity verification system that detects and orients Egyptian ID cards, locates fields, extracts Arabic text, checks authenticity, and compares the cardholder photo with a live facial image.",
    stack: ["YOLOv8", "Surya OCR", "DeepFace", "OpenCV", "React.js", "FastAPI", "Hugging Face"],
  },
  {
    title: "Discord Image Reader",
    period: "Jan 2025 — Feb 2025",
    icon: Terminal,
    description:
      "A Discord bot that extracts text from images shared in a server and automatically responds with recognized text.",
    stack: ["Python", "Discord", "OCR", "Image Processing"],
  },
  {
    title: "Parking System Simulation",
    period: "Nov 2024 — Jan 2025",
    icon: Layers3,
    description:
      "A C++ parking-system simulation implementing automatic vehicle entry, exit, parking-fee tracking, and a simple user interface.",
    stack: ["C++", "OOP", "Algorithms"],
  },
  {
    title: "Library Website",
    period: "Apr 2024 — Jul 2024",
    icon: Code2,
    description:
      "A full-stack library website with API-based functionality, GitHub OAuth, and repository activity visualization.",
    stack: ["HTML", "CSS", "JavaScript", "Django", "GitHub OAuth"],
  },
  {
    title: "Image Filters",
    period: "Apr 2023 — May 2023",
    icon: Cpu,
    description:
      "A C++ image-processing application implementing grayscale, inversion, blur, and an object-oriented filtering architecture.",
    stack: ["C++", "OOP", "Image Processing"],
  },
  {
    title: "X/O Game — Multiple Boards",
    period: "Jan 2023 — Mar 2023",
    icon: BrainCircuit,
    description:
      "A customizable X/O game supporting multiple board sizes and game modes, built with advanced C++ and OOP concepts.",
    stack: ["C++", "OOP", "Game Logic"],
  },
];

const skills = [
  { group: "Programming", items: ["Python", "C++", "Java", "JavaScript", "SQL", "HTML/CSS"] },
  { group: "AI & Computer Vision", items: ["YOLOv8", "Surya OCR", "DeepFace", "ArcFace", "Facenet512", "Facenet", "OpenCV", "Deep Learning"] },
  { group: "Web & Frameworks", items: ["React.js", "FastAPI", "Django", "Node.js", "REST APIs", "GitHub OAuth", "Hugging Face"] },
  { group: "Cybersecurity & Networking", items: ["HCIP Security", "Red Team Fundamentals", "Vulnerability Scanning", "CCNA Networking"] },
  { group: "Systems & Concepts", items: ["Ubuntu Linux", "Red Hat System Administration", "Git", "GitHub", "OOP", "Data Structures", "Algorithms", "Problem Solving"] },
];

const certifications = [
  "Huawei — HCIP Security CTSS",
  "Red Hat — System Administration I (RH124)",
  "NVIDIA — Deep Learning",
  "Ubuntu Linux Essentials",
  "Cisco — CCNA",
  "CompTIA — A+",
  "CompTIA — Network+",
  "Goethe-Institut — German B1",
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setMenuOpen(false);
  };

  return (
    <div className="app">
      <div className="noise" />
      <header className={`nav ${scrolled ? "nav-scrolled" : ""}`}>
        <button className="brand" onClick={() => go("home")} aria-label="Go home">
          <span className="brand-mark">SE</span>
          <span>Seif<span className="accent">.</span></span>
        </button>

        <nav className={menuOpen ? "nav-links open" : "nav-links"}>
          {["about", "projects", "skills", "experience", "contact"].map((item) => (
            <button key={item} onClick={() => go(item)}>
              {item}
            </button>
          ))}
          <a className="nav-cta" href={profile.github} target="_blank" rel="noreferrer">
            GitHub <ArrowUpRight size={15} />
          </a>
        </nav>

        <button className="menu-btn" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">
          {menuOpen ? <X /> : <Menu />}
        </button>
      </header>

      <main>
        <section id="home" className="hero section">
          <div className="hero-grid" />
          <div className="hero-content">
            <div className="eyebrow"><span className="pulse" /> Available for opportunities</div>
            <h1>
              Building software at the intersection of
              <span className="gradient-text"> AI, engineering & security.</span>
            </h1>
            <p className="hero-copy">
              Computer Science and AI student focused on software engineering,
              computer vision, cybersecurity, and practical systems that solve real problems.
            </p>
            <div className="hero-actions">
              <button className="primary-btn" onClick={() => go("projects")}>
                Explore my work <ArrowDown size={17} />
              </button>
              <a className="secondary-btn" href={profile.linkedin} target="_blank" rel="noreferrer">
                LinkedIn <ArrowUpRight size={17} />
              </a>
            </div>
            <div className="hero-meta">
              <span><GraduationCap size={17} /> Cairo University</span>
              <span><Network size={17} /> AI · Security · Software</span>
              <span><span className="dot" /> Cairo, Egypt</span>
            </div>
          </div>

          <div className="hero-orbit" aria-hidden="true">
            <div className="orbit orbit-a" />
            <div className="orbit orbit-b" />
            <div className="orbit-core">
              <BrainCircuit size={48} />
              <span>AI</span>
            </div>
            <span className="float-tag tag-1">Python</span>
            <span className="float-tag tag-2">C++</span>
            <span className="float-tag tag-3">CV</span>
            <span className="float-tag tag-4">Security</span>
          </div>
        </section>

        <section id="about" className="section split-section">
          <div className="section-label">01 / About</div>
          <div>
            <h2>Curious by nature.<br /><span className="muted">Builder by practice.</span></h2>
            <p className="large-copy">
              I’m Seif Elmahalawy, a Computer Science and Artificial Intelligence student at Cairo University.
              My work combines software engineering with AI, computer vision, networking, and cybersecurity.
            </p>
            <p className="body-copy">
              I enjoy turning technical ideas into working products — from an AI-powered Egyptian ID
              verification system to image-processing applications, full-stack websites, and security tooling.
              My approach is practical: understand the problem, build the system, test it, and keep improving it.
            </p>
            <div className="mini-stats">
              <div><strong>2026</strong><span>Expected graduation</span></div>
              <div><strong>6+</strong><span>Featured projects</span></div>
              <div><strong>8+</strong><span>Certifications</span></div>
            </div>
          </div>
        </section>

        <section id="projects" className="section projects-section">
          <div className="section-heading">
            <div>
              <div className="section-label">02 / Selected work</div>
              <h2>Things I’ve <span className="gradient-text">built.</span></h2>
            </div>
            <a href={profile.github} target="_blank" rel="noreferrer" className="text-link">
              View GitHub <ArrowUpRight size={17} />
            </a>
          </div>

          <div className="projects-grid">
            {projects.map((p, i) => {
              const Icon = p.icon;
              return (
                <article className={`project-card ${p.featured ? "featured" : ""}`} key={p.title}>
                  <div className="project-top">
                    <div className="project-icon"><Icon size={21} /></div>
                    <span className="project-number">0{i + 1}</span>
                  </div>
                  <div className="project-period">{p.period}</div>
                  <h3>{p.title}</h3>
                  <p>{p.description}</p>
                  <div className="tags">
                    {p.stack.map((tag) => <span key={tag}>{tag}</span>)}
                  </div>
                  <a className="project-link" href={profile.github} target="_blank" rel="noreferrer">
                    Explore on GitHub <ArrowUpRight size={16} />
                  </a>
                </article>
              );
            })}
          </div>
        </section>

        <section id="skills" className="section skills-section">
          <div className="section-label">03 / Toolkit</div>
          <div className="skills-heading">
            <h2>A stack built for <span className="gradient-text">real problems.</span></h2>
            <p>From low-level programming and algorithms to AI systems and security tooling.</p>
          </div>
          <div className="skills-grid">
            {skills.map((s) => (
              <div className="skill-group" key={s.group}>
                <h3>{s.group}</h3>
                <div className="skill-list">
                  {s.items.map((item) => (
                    <span key={item}><CheckCircle2 size={14} /> {item}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        <section id="experience" className="section experience-section">
          <div className="section-label">04 / Experience</div>
          <div className="timeline">
            <div className="timeline-item">
              <div className="timeline-marker" />
              <div className="timeline-head">
                <div>
                  <h3>Minders · Cairo University</h3>
                  <p>Sep 2024 — Present · Cairo, Egypt</p>
                </div>
                <span className="role-chip">Technical Experience</span>
              </div>
              <ul>
                <li>Used Git and foundational software engineering practices to troubleshoot and resolve computer issues for community members.</li>
                <li>Developed Python scripts to automate network vulnerability scans during Red Team cybersecurity exercises.</li>
              </ul>
            </div>
            <div className="timeline-item">
              <div className="timeline-marker" />
              <div className="timeline-head">
                <div>
                  <h3>Resala Charity Organization</h3>
                  <p>Jun 2023 — Sep 2023 · Volunteer</p>
                </div>
                <span className="role-chip">Community</span>
              </div>
              <ul>
                <li>Coordinated with volunteers to plan and execute community events while maintaining organized documentation.</li>
                <li>Strengthened teamwork, communication, and community-service skills through direct collaboration.</li>
              </ul>
            </div>
          </div>

          <div className="certs">
            <div className="certs-title"><ShieldCheck size={20} /> Certifications & training</div>
            <div className="cert-grid">
              {certifications.map((c) => <span key={c}>{c}</span>)}
            </div>
          </div>
        </section>

        <section id="contact" className="section contact-section">
          <div className="contact-card">
            <div className="contact-glow" />
            <div className="section-label">05 / Contact</div>
            <h2>Have a project in mind?</h2>
            <p>Let’s build something useful, reliable, and technically interesting.</p>
            <div className="contact-actions">
              <a className="primary-btn" href={`mailto:${profile.email}`}>
                <Mail size={17} /> Get in touch
              </a>
              <a className="secondary-btn" href={profile.github} target="_blank" rel="noreferrer">
                <Github size={17} /> GitHub
              </a>
              <a className="secondary-btn" href={profile.linkedin} target="_blank" rel="noreferrer">
                <Linkedin size={17} /> LinkedIn
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer>
        <span>© {new Date().getFullYear()} Seif Elmahalawy</span>
        <span>Designed & built with React + Vite</span>
      </footer>

      <button className="back-top" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} aria-label="Back to top">
        <ArrowUp size={18} />
      </button>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
